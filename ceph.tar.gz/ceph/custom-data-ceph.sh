#!/bin/bash
sed -i 's/AlmaLinux/CentOS/g' /etc/*release