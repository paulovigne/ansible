# Ansible role: ceph_defaults

Documentation is available at http://docs.ceph.com/cephadm-ansible/.
